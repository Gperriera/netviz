--
--Copyright (c) 2015 AppDynamics Inc.
-- All rights reserved.
 --
 -- $Id$

package.path = './?.lua;' .. package.path

appd_diagnostics = {
	rlimit_soft = 30000000,
	rlimit_hard = 40000000,
	pr_set_dumpable = 1,
	init_pause = 0,
}

appd_netagent_diagnostics = {
	rlimit_soft = 30000000,
	rlimit_hard = 40000000,
	pr_set_dumpable = 1,
	init_pause = 0,
}

appd_netmon_diagnostics = {
	rlimit_soft = 30000000,
	rlimit_hard = 40000000,
	pr_set_dumpable = 1,
	init_pause = 0,
}
